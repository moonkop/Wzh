#ifndef __MOTOR_H
#define __MOTOR_H
#include "stm32f4xx.h"
void setSpeed(s16 left, s16 right);
void motor_init();

#endif // !__MOTOR_H

