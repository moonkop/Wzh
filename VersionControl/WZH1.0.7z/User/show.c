//************������־�Ƽ�***************************************************************

//�뱾�������׵�Ӳ����https://item.taobao.com/item.htm?id=530846387509
//ʹ�ù�������ʲô������������ϵ���������߼ӵ���QQ��544645244

//************������־�Ƽ�***************************************************************
#include "show.h"
#include "devices\lcd.h"
#include <stdarg.h>
unsigned char i;          //��������
unsigned char Send_Count; //������Ҫ���͵����ݸ���
float Vol;
u8 oled_delay;
int currentChar = 0;
int currentLine = 0;
int bufferCount=0;
char currentLineBuffer[25]="";

void newLine()
{
	currentLineBuffer[currentChar]=0;
	//applendToBuffer(currentLineBuffer);
	
	currentLine++;
	currentChar = 0;
	bufferCount++;
	if(currentLine==8)
		currentLine=0;
}

void oled_putch(char ch,u8 mode)
{
	if(currentChar>24)
	{
		newLine();
	}
	currentLineBuffer[currentChar] = ch;
	switch(ch)
	{
		case '\a': 
			return;
		case '\b': currentChar--;
			return;
		case '\t': currentChar =(currentChar/8+1)*8;
			return;
		case '\n':
			newLine();
			return;
		case '\v': 
			return;
		case '\f': 
			return;
		case '\r':
			newLine();
			return;
	}
	LCD_DisplayChar(currentChar++ * 6, currentLine * 8, ch, 12);

	
	//oled_ShowChar58(currentChar++*5,currentLine*8,ch,mode);
}
void oled_printstr(char* str)
{
		while(*str)
		{
			oled_putch(*str++,1);
		}
}
void oled_printDec(int num)
{
	char str[32] = "";
	int len = 0;
	do	str[len++] = num % 10 + 48; while (num/=10);
	while (len--)	oled_putch(str[len],1);
}
void oled_printHex(int hex)
{
	
}
void oled_printFloat(double num)
{
	int numInt=(int)num;
	oled_printDec(numInt);
	num-=numInt;
	oled_putch('.',1);
	oled_printDec((int)(num*1000));
}
void oled_printf(char* fmt,...)
{
	double varFloat=0;
	int varInt=0;
	char* varStr=NULL;
	char varCh=0;
	va_list vp;
	char * pfmt=NULL;
	va_start(vp,fmt);
	pfmt=fmt;
	
	while(*pfmt)
	{
		if(*pfmt=='%')
		{
			switch(*(++pfmt))
			{
				case 'c':
					varCh=va_arg(vp,int);
					oled_putch(varCh,1);
				break;
				
				case 'd':
				case 'i':
					varInt=va_arg(vp,int);			
					oled_printDec(varInt);
				break;
				
				case 'f':
					varFloat=va_arg(vp,double);
					oled_printFloat(varFloat);
				
					break;
				
				case 's':
					varStr=va_arg(vp,char*);
					oled_printstr(varStr);
				
					break;
				
				case 'b':
				case 'B':
					
					break;
				
				
				case 'x':	
				case 'X':
					break;
				
				case '%':
					break;
			}
			pfmt++;
		}
		else
		{
			oled_putch(*pfmt++,1);
			
		}
	}

}


void oled_show(void)
{
	//oled_DrawSquare(10,10,50,50,1);
	//oled_DrawSquare(20,20,5,5,0);
	//oled_DrawSquare(20,30,5,5,0);

	

//	for(int j =0;j<6;j++)
//	{
//		for(int i =0;i<16;i++)
//		{
//			oled_ShowChar58(i*5,j*8,ch++,1);
//		}	
//	}
//	
//	oled_printstr("temp=\t"); 	oled_printstr("474\n");
//	oled_printstr("num=\t"); 	oled_printstr("18015165916\n");
//	oled_printstr("humid=\t"); 	oled_printstr("2115110220\n");
//	Linklisttest();
	oled_printf("%d\n",bufferCount);
	
	
	//OLED_Refresh_Gram();//��ʼ��ʾ
}
void OLED_Show_progress_bar(u8 temp,u8 chr_star,u8 chr_default,u8 x,u8 y,u8 size,u8 mode)
{
	if(temp>=0&&temp<=12)
	{
		//OLED_Show_CH(x,y,chr_star+temp,size,size);
		
	}
	else
	{
		//OLED_Show_CH(x,y,chr_default,size,size);
	}
}

