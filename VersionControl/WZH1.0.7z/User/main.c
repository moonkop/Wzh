#include "main.h"
#include "lcd.h"
#include "ADC.h"
#include "LED.h"
#include "RCC.h"
#include "sen2020.h"
#include "TIM.h"
#include "USART.h"
#include "USART_DMA.h"
#include "common.h"
#include "stdint.h"
#include "task.h"
#include "motor.h"

int LCD_currentLine = 0;



void delay(int i )
{
	while(i--)
		for(int j=0;j<10000;j++);
}


void printStr(unsigned char* str)
{
	LCD_DisplayString(0, LCD_currentLine++ * 12, 12, str);

}



int main(void)
{
	
	//LED_init();
	delay_init();
	RCC_init();
	//LCD_Init();
	TIM4_init();
	TIM3_OC_init();
	TIM3_init();
	SEN2020_init();
	 LED_init();
	LED_SET(2,1);
	motor_init();
	//GPIO_SetBits(GPIOG,GPIO_Pin_9);
	while (1)
	{
		MainLoop();

	}
}

