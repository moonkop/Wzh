#ifndef __SEN2020_H
#define __SEN2020_H
#include "USART.h"
#include "USART_DMA.h"
void SEN2020_init(void);
u8 getSEN2020DigitalData(void);
#endif // !__SEN2020_H
