#ifndef __USART_DMA_H
#define __USART_DMA_H

void USART1_DMA_TX_Init(void);

void USART1_DMA_RX_Init(void);
#endif // !__USART_DMA_H
