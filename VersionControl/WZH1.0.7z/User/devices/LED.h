#ifndef __LED_H
#define __LED_H
void LED_init(void);
void LED_SET(int i, int mode);
#endif // __LED_H
