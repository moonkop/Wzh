#include"stm32f4xx.h"
#include "ADC.h"
void ADC_init()
{

}
