#ifndef __TIM_H
#define __TIM_H
void TIM4_init(void);
void TIM3_OC_init(void);
void TIM3_init(void );
#endif // !__TIM_H
