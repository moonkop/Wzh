#ifndef __USART_H
#define __USART_H


void USART1_init(void);

void USART2_init(void);

void USART3_init(void);

void USART4_init(void);

void USART5_init(void);

#endif // !__USART_H
