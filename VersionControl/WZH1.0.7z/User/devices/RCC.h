#ifndef __RCC_H
#define __RCC_H
void RCC_init(void);

#endif // !__RCC_H
