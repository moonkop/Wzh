#ifndef __TRACK_H
#define __TRACK_H

void getLines(u8* sensers);

void getToLine1();















#endif // !__TRACK_H
