#include "main.h"
int buttonIRLeft = 0;
int buttonIRRight = 0;




void getButtonIRdata()
{
	 buttonIRRight = Get_Adc(ADC_Channel_5);
	 buttonIRLeft = GetAdc3(ADC_Channel_9);
	 LCD_printf("r=%d\tl=%d\n", buttonIRRight, buttonIRLeft);

}