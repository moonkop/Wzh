#include "LCD_print.h"
#include "lcd.h"
#include <stdarg.h>
int currentChar = 0;
int currentLine = 0;
int bufferCount = 0;
char currentLineBuffer[25] = "";

#define HEIGHT 320
#define WIDTH 240


//-----settings=----//
int  PRINTCHARSIZE=		16;
int bufferTop = 160;
int bufferleft = 0;
int bufferHeight = 160;
int bufferWitdh = 240;
//-----settings=----//




int heightPerChar =		0;
int widthPerChar =		0;
int bufferLines =		0;
int bufferwidthChar =	0;




void LCD_Print_init()
{
	int charwidth = PRINTCHARSIZE / 2;
	 currentChar = 0;
	 currentLine = 0;
	switch (PRINTCHARSIZE)
	{
	case 12:
		bufferLines = bufferHeight / PRINTCHARSIZE;
		bufferwidthChar = bufferWitdh / charwidth;
		heightPerChar = 12;
		widthPerChar = 6;
		break;

	case 16:
		bufferLines = bufferHeight / PRINTCHARSIZE;
		bufferwidthChar = bufferWitdh / charwidth;
		heightPerChar = 16;
		widthPerChar = 8;
		break;
	case 24:
		bufferLines = bufferHeight / PRINTCHARSIZE;
		bufferwidthChar = bufferWitdh / charwidth;
		heightPerChar = 24;
		widthPerChar = 12;
		break;

	default:
		bufferLines = bufferHeight / PRINTCHARSIZE;
		bufferwidthChar = bufferWitdh / charwidth;
		heightPerChar = 12;
		widthPerChar = 6;
		break;
	}
}
void LCD_ClearLine(int line)
{

}

void newLine()
{
	//currentLineBuffer[currentChar] = 0;
//	applendToBuffer(currentLineBuffer);

	currentLine++;
	currentChar = 0;
	bufferCount++;
	if (currentLine == bufferLines)
		currentLine = 0;
	LCD_Fill_onecolor(bufferleft,bufferTop+ currentLine*heightPerChar,bufferleft+bufferWitdh,bufferTop+ (currentLine+1)*heightPerChar,0xffff);
}


void LCD_putch(char ch)
{
	if (currentChar > bufferwidthChar)
	{
		newLine();
	}
	//currentLineBuffer[currentChar] = ch;
	switch (ch)
	{
	case '\a':
		return;
	case '\b': currentChar--;
		return;
	case '\t': currentChar = (currentChar / 8 + 1) * 8;
		return;
	case '\n':
		newLine();
		return;
	case '\v':
		return;
	case '\f':
		return;
	case '\r':
		newLine();
		return;
	}

	LCD_DisplayChar(currentChar++ * widthPerChar +bufferleft, currentLine * heightPerChar +bufferTop, ch, PRINTCHARSIZE);
}

void LCD_printstr(char* str)
{
	while (*str)
	{
		LCD_putch(*str++);
	}
}
void LCD_printDec(int num)
{
	char str[32] = "";
	int len = 0;
	do	str[len++] = num % 10 + 48; while (num /= 10);
	while (len--)	LCD_putch(str[len]);
}
void LCD_printHex(int hex)
{
	char str[20] = "";
	int len = 0;
	do
	{
		str[len++] = hex  &0x0f;
	} while (hex>>=4);
	while (len--)
	{
		if (str[len]<10)
		{
			LCD_putch(str[len]+48);

		}
		else
		{
			LCD_putch(str[len]-10 + 65);
		}
	}
}
void LCD_printBin(int bin)
{
	char str[32] = "";
	int len = 0;
	do
	{
		str[len++] = bin & 0x01;
	} while (bin >>= 1);
	while (len--)
	{
			LCD_putch(str[len] + 48);
	}
}
void LCD_printFloat(double num)
{
	int numInt = (int)num;
	LCD_printDec(numInt);
	num -= numInt;
	LCD_putch('.');
	LCD_printDec((int)(num * 1000));
}

void LCD_printf(char* fmt, ...)
{
	double varFloat = 0;
	int varInt = 0;
	char* varStr = NULL;
	char varCh = 0;
	va_list vp;
	char * pfmt = NULL;
	va_start(vp, fmt);
	pfmt = fmt;

	while (*pfmt)
	{
		if (*pfmt == '%')
		{
			switch (*(++pfmt))
			{
			case 'c':
				varCh = va_arg(vp, int);
				LCD_putch(varCh);
				break;

			case 'd':
			case 'i':
				varInt = va_arg(vp, int);
				LCD_printDec(varInt);
				break;

			case 'f':
				varFloat = va_arg(vp, double);
				LCD_printFloat(varFloat);
				break;
			case 's':
				varStr = va_arg(vp, char*);
				LCD_printstr(varStr);
				break;
			case 'b':
			case 'B':
				varInt = va_arg(vp, int);
				LCD_printBin(varInt);
				break;
			case 'x':
			case 'X':
				varInt = va_arg(vp, int);
				LCD_printHex(varInt);
				break;

			case '%':
				LCD_putch('%');
				break;
			}
			pfmt++;
		}
		else
		{
			LCD_putch(*pfmt++);
		}
	}

}