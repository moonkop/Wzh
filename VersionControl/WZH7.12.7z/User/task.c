#include "main.h"
int Count_1ms;
int Count_2ms;
int Count_4ms;
int Count_20ms;
int Count_50ms;
int Count_1s;
u8 Task_check_flag;
extern u8 SEN2020Array[8];

void MainLoop()
{
 	if (Task_check_flag)
	{

		if (Count_1ms >= 1)
		{
			Count_1ms = 0;
			Task_1000HZ();
		}
		if (Count_2ms >= 2)
		{
			Count_2ms = 0;
			Task_500HZ();
		}
		if (Count_4ms >= 4)
		{
			Count_4ms = 0;
			Task_250HZ();
		}
		if (Count_20ms >= 20)
		{
			Count_20ms = 0;
			Task_50HZ();
		}
		if (Count_50ms >= 50)
		{
			Count_50ms = 0;
			Task_20HZ();
		}
		if (Count_1s >= 1000)
		{
			Count_1s = 0;
			Task_1HZ();
		}
		Task_check_flag = 0;
	}
}


void loopCounter()
{
	Count_1ms++;
	Count_2ms++;
	Count_4ms++;
	Count_20ms++;
	Count_1s++;
	Count_50ms++;

	Task_check_flag = 1;
}

void  Task_1000HZ(void)
{

}

void Task_500HZ(void)
{

}

void Task_250HZ(void)
{

}

void Task_50HZ(void)
{

	
	getButtonIRdata();
	track_on_bridge();

	
	getSEN2020DigitalData();
	getLines(SEN2020Array);
	//getToLine1();
}
int i=0;

void Task_20HZ(void)
{
	i++;

}
void Task_1HZ(void)
{


	//setSpeed(10,10);
}
