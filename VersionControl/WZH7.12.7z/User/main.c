#include "main.h"


void delay(int i )
{
	while(i--)
		for(int j=0;j<10000;j++);
}
int main(void)
{
	
	LED_init();
	delay_init();
	RCC_init();
	LCD_Init();
	TIM4_init();
	TIM3_OC_init();
	TIM3_init();
	SEN2020_init();
	LED_init();
	LED_SET(2,1);
	motor_init();
	LCD_Init();

	LCD_Print_init();
	LCD_printf("ADC initing\n");
	ADC1_Init();
	ADC3_init();
	LCD_printf("Initialize finished\n");

	delay_ms(1500);
	
	
	//GPIO_SetBits(GPIOG,GPIO_Pin_9);
	while (1)
	{
		MainLoop();

	}
}

