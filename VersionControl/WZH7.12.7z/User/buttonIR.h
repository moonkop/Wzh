#ifndef __BUTTON_IR
#define	__BUTTON_IR

extern int buttonIRLeft ;
extern int buttonIRRight ;


void getButtonIRdata();

#endif // !__BUTTON_IR
