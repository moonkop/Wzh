#ifndef __MAIN_H
#define __MAIN_H
#include "lcd.h"
#include "ADC.h"
#include "LED.h"
#include "RCC.h"
#include "sen2020.h"
#include "TIM.h"
#include "USART.h"
#include "USART_DMA.h"
#include "common.h"
#include "stdint.h"
#include "task.h"
#include "motor.h"
#include "common.h"
#include "LCD_print.h"
#include "track.h"
#include "buttonIR.h"
#endif // !__MAIN_H


