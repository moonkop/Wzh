#ifndef __LCD_PRINT_H
#define __LCD_PRINT_H
#include "stm32f4xx.h"




void LCD_Print_init();

void newLine();

void LCD_putch(char ch);

void LCD_printstr(char * str);

void LCD_printDec(int num);

void LCD_printHex(int hex);

void LCD_printFloat(double num);

void LCD_printf(char * fmt, ...);




#endif // !__LCD_PRINT_H
