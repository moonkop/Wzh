#ifndef __MAIN_H
#define __MAIN_H
#define LIMIT(val,min,max) ((val<min)?min:((val>max)?max:val))
#include "lcd.h"
#include "ADC.h"
#include "LED.h"
#include "RCC.h"
#include "sen2020.h"
#include "TIM.h"
#include "USART.h"
#include "USART_DMA.h"
#include "common.h"
#include "stdint.h"
#include "task.h"
#include "motor.h"
#include "common.h"
#include "LCD_print.h"
#include "track.h"
#include "buttonIR.h"
#include "motorEncoder.h"
#include "LCD_show.h"
#endif // !__MAIN_H

