#include "motor.h"
#include "TIM.h"

s16 LeftSpeedOut = 0;
s16 RightSpeedOut = 0;
int leftEncoderCount = 0;
int RightEncoderCount = 0;
int leftCurrentEncoderCount = 0;
int RightCurrentEncoderCount = 0;


void setSpeed(s16 left,s16 right)
{

	LeftSpeedOut = left;
	RightSpeedOut = right;

	GPIO_ResetBits(GPIOG, GPIO_Pin_15);

	GPIO_ResetBits(GPIOA, GPIO_Pin_4);

	GPIO_ResetBits(GPIOC, GPIO_Pin_6);

	GPIO_ResetBits(GPIOD, GPIO_Pin_7);


	if (left>0)
	{GPIO_SetBits(GPIOA, GPIO_Pin_4);
		
	}
	else
	{
		GPIO_SetBits(GPIOG, GPIO_Pin_15);
		left = -left;
	}
	if (right>0)
	{
		GPIO_SetBits(GPIOD, GPIO_Pin_7);
	}
	else
	{GPIO_SetBits(GPIOC, GPIO_Pin_6);
		
		right = -right;
	}

	TIM_SetCompare2(TIM3, left);
	TIM_SetCompare3(TIM3, right);
}



void getEncoderCount()
{
	leftEncoderCount = leftCurrentEncoderCount;
	RightEncoderCount = RightCurrentEncoderCount;
	leftCurrentEncoderCount = 0;
	RightCurrentEncoderCount = 0;
}



/*

TIM3
//C6 tim3 ch1
C7 tim3 ch2 left
C8 tim3 ch3 right
//C9 tim3 ch4

G15 	L F
A4		L B

C6		R F
D7		R B


*/


void _motor_gpio_init(GPIO_TypeDef * GPIOx, int GPIO_Pin)
{

	GPIO_InitTypeDef g;
	
	g.GPIO_Mode = GPIO_Mode_OUT;
	g.GPIO_OType = GPIO_OType_PP;
	g.GPIO_Speed = GPIO_Speed_100MHz;
	g.GPIO_PuPd = GPIO_PuPd_DOWN;
	g.GPIO_Pin = GPIO_Pin;
	GPIO_Init(GPIOx, &g);
}
void motor_init()
{
	TIM3_init();
	_motor_gpio_init(GPIOG, GPIO_Pin_15); //LF

	_motor_gpio_init(GPIOA, GPIO_Pin_4);  //LB

	_motor_gpio_init(GPIOC, GPIO_Pin_6);  //RF

	_motor_gpio_init(GPIOD, GPIO_Pin_7);  //RB
}