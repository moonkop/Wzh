#ifndef __LCD_SHOW_H
#define __LCD_SHOW_H

#include "stm32f4xx.h"
typedef struct _LCD_Show_Structure LCD_Show_Structure;

typedef struct  _LCD_Show_Structure
{
	u16 top;
	u16 left;
	u16 widthChar;
	u16 _width;
	u8 fontSize;
	u8 _fontWidth;
	
	char * name;
	int _namelength;
	int* dataPtr;
	int data;
	u8 showBorder;
	void (*showFunction)(int signal, LCD_Show_Structure *  structure);
	
	int _currentOffset;
	

} LCD_Show_Structure;


void LCD_Show_init();

void LCD_Show_Structure_Add(int * dataPtr, u8 fontsize, u16 top, u16 left, u16 widthChar, char * name, u8 showBorder, void(*showFunction)(int, LCD_Show_Structure *));

int strlen(char * str);


void LCD_Show();

void LCD_showStructure(LCD_Show_Structure * lcd);

void _LCD_Show_Clear_Area(LCD_Show_Structure * lcd);

void _LCD_Show_Draw_Border(LCD_Show_Structure * lcd);



#endif // !__LCD_SHOW_H
