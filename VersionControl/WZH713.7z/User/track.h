#ifndef __TRACK_H
#define __TRACK_H

void getLines(u8* sensers);

void getToLine1();

void track_on_bridge();















#endif // !__TRACK_H
