#include "stm32f4xx.h"
#include "track.h"
#include "motor.h"
u8 linecount = 0;
int  lines[8];
u8*	sensers=0;
void getLines(u8* sensers)
{

	linecount = 0;			//lines under the senser
	u8 currentLineCount = 0; //current sensers count actived by line
	u8 currentLineSum = 0;	//current sensers Number sum 
	u8 lineFlag = 0;				// current itearter is under the line 
									//	ConvertToArray(); //Convert senser data to senser[8] array
	for (int i = 0; i < 8; i++)
	{
		if (lineFlag == 1)
		{
			if (sensers[i] == 0)
			{
				lines[linecount++] = currentLineSum * 10 / currentLineCount;
				currentLineCount = 0;
				currentLineSum = 0;
				lineFlag = 0;
			}
			else if (sensers[i] == 1)
			{
				currentLineCount++;
				currentLineSum += i;
			}
		}
		else if (lineFlag == 0)
		{
			if (sensers[i] == 0)
			{
				continue;
			}
			else if (sensers[i] == 1)
			{
				lineFlag = 1;
				currentLineCount++;
				currentLineSum += i;
			}
		}
	}
	if (lineFlag == 1)
	{
		lines[linecount++] = currentLineSum * 10 / currentLineCount;
		currentLineCount = 0;
		currentLineSum = 0;
		lineFlag = 0;
	}
}
void getToLine1()
{
	s16 straightSpeed = 40;
	float kp = 2;

	if (linecount == 1)
	{
		u16 line = lines[0];
		int reviseSpeed = (int)((line-35) * kp);

		setSpeed(straightSpeed - reviseSpeed, straightSpeed + reviseSpeed);

	}
}