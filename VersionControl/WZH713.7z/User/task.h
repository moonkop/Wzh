#ifndef __TASK_H
#define __TASK_H
void MainLoop(void);
void loopCounter(void);

void Task_1000HZ(void);

void Task_500HZ(void);

void Task_250HZ(void);

void Task_50HZ(void);

void Task_20HZ(void);

void Task_1HZ(void);


#endif // !__TASK_H
