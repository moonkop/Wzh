#ifndef __LCD_PRINT_H
#define __LCD_PRINT_H
#include "stm32f4xx.h"
#include "LCD_show.h"
#define  PRINTCHARSIZE 16

#define HEIGHT 320
#define WIDTH 240
#define LCD_printstr(val)	_LCD_printstr(val,NULL)
#define LCD_printDec(val)	_LCD_printDec(val,NULL)
#define LCD_printHex(val)	_LCD_printHex(val,NULL)
#define LCD_printBin(val)	_LCD_printBin(val,NULL)
#define LCD_printFloat(val) _LCD_printFloat(val,NULL)

void LCD_Print_init();

void _LCD_newLine();

void LCD_putch(char ch, LCD_Show_Structure * structure);

void _LCD_printstr(char * str, LCD_Show_Structure * structure);

void _LCD_printDec(int num, LCD_Show_Structure * structure);

void _LCD_printHex(int hex, LCD_Show_Structure * structure);

void _LCD_printBin(int bin, LCD_Show_Structure * structure);

void _LCD_printFloat(double num, LCD_Show_Structure * structure);

void LCD_printf(char * fmt, ...);




#endif // !__LCD_PRINT_H
