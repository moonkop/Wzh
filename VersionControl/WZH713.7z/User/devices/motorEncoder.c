#include "main.h"


extern int leftEncoderCount;
extern int RightEncoderCount;
extern int leftCurrentEncoderCount;
extern int RightCurrentEncoderCount;


void motorEncoder_init()
{
	GPIO_InitTypeDef g;
	g.GPIO_Mode = GPIO_Mode_IN;
	g.GPIO_OType = GPIO_OType_OD;
	g.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	g.GPIO_PuPd = GPIO_PuPd_DOWN;
	g.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOF, &g);


	EXTI_InitTypeDef e;
	e.EXTI_Line = EXTI_Line12 | EXTI_Line13 | EXTI_Line14 | EXTI_Line15 ;
	e.EXTI_LineCmd = ENABLE;
	e.EXTI_Mode = EXTI_Mode_Interrupt;
	e.EXTI_Trigger = EXTI_Trigger_Falling;
	
	EXTI_Init(&e);
	
	NVIC_InitTypeDef n;
	n.NVIC_IRQChannel = EXTI15_10_IRQn;
	n.NVIC_IRQChannelCmd = ENABLE;
	n.NVIC_IRQChannelPreemptionPriority = 1;
	n.NVIC_IRQChannelSubPriority = 0;

	NVIC_Init(&n);
}

extern "C"
{
	void EXTI15_10_IRQHandler(void)
	{
		if (EXTI_GetITStatus(EXTI_Line12) != RESET)
		{
			EXTI_ClearITPendingBit(EXTI_Line12);

		}
		if (EXTI_GetITStatus(EXTI_Line13) != RESET)
		{
			EXTI_ClearITPendingBit(EXTI_Line13);

		}
		if (EXTI_GetITStatus(EXTI_Line14) != RESET)
		{
			EXTI_ClearITPendingBit(EXTI_Line14);

		}
		if (EXTI_GetITStatus(EXTI_Line15) != RESET)
		{
			EXTI_ClearITPendingBit(EXTI_Line15);

		}

	}
}
