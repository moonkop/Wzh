
#include "main.h"
#include "LCD_show.h"

LCD_Show_Structure  lcds[20];
int lcdscount = 0;
extern int buttonIRRight;


extern u8 SEN2020Datas;


void LCD_Show_init()
{

	LCD_Show_Structure_Add(
		&buttonIRRight,
		16,
		1,
		1,
		4,
		"IR R ",
		1,
		_LCD_printDec
		);
	
		LCD_Show_Structure_Add(
		&buttonIRLeft,
		16,
		0,
		100,
		4,
		"L ",
		1,
		_LCD_printDec
		);
		
		LCD_Show_Structure_Add(
		(int *)&SEN2020Datas,
		16,
		17,
		1,
		8,
		"SEN ",
		1,
		_LCD_printBin
		);
	
}
/**
* @brief  API FUNCTION  add a Led_show_structure to lcds array 
* @param  dataPtr:specifies  The pointer to the data to show 
* @param  fontsize:specifies  font size of data to show 
*          This parameter can be 12 16 24.
* @param  top: specifies the distance from the position to the top of the screen;
*          This parameter can be from 0 to the height of lcd Normally 320
* @param  left: specifies the distance from the position to the left of the screen;
*          This parameter can be from 0 to the width of lcd Normally 240
* @param  widthChar: specifies num of chararters to be show it decides the width of the block  will be cleaned afterwards
*          This parameter can be any combination of GPIO_Pin_x where x can be (0..15).
* @param  name: specifies the name of the block it can be shown 
*          This parameter can be any combination of GPIO_Pin_x where x can be (0..15).
* @param  showBorder: specifies whether the borader border of the block is visable
*          This parameter can be any combination of GPIO_Pin_x where x can be (0..15).
* @retval None
*/

//api function 
void LCD_Show_Structure_Add(
	int *dataPtr,	
	u8 fontsize,	
	u16 top,
	u16 left,
	u16 widthChar,
	char* name,
	u8 showBorder,
	void(*showFunction)(int, LCD_Show_Structure *)
)
{
	lcds[lcdscount].name = name;
	if (name != NULL)
	{
		lcds[lcdscount]._namelength = strlen(lcds[lcdscount].name);
	}
	else
	{
		lcds[lcdscount]._namelength = 0;
	}
	lcds[lcdscount].widthChar = widthChar + lcds[lcdscount]._namelength;

	lcds[lcdscount].dataPtr = dataPtr;
	lcds[lcdscount].fontSize = fontsize;
	lcds[lcdscount]._fontWidth = fontsize / 2;
	lcds[lcdscount].top = top;
	
	lcds[lcdscount].showFunction = showFunction;
	lcds[lcdscount].left = left;
	lcds[lcdscount].showBorder = showBorder;
	lcds[lcdscount]._width = lcds[lcdscount].widthChar*lcds[lcdscount]._fontWidth;

	lcdscount++;

}
int strlen(char * str)
{
	int i = 0;
	while (*(str++))
		i++;
	return i;
}
void LCD_Show()
{

	for (int i = 0; i < lcdscount; i++)
	{
		LCD_showStructure(&lcds[i]);
	}
}
void LCD_showStructure(LCD_Show_Structure* lcd)
{
	lcd->_currentOffset = 0;
	_LCD_Show_Clear_Area(lcd);
	if (lcd->showBorder)
	{
		_LCD_Show_Draw_Border(lcd);
	}
	if (lcd->dataPtr != NULL)
	{
		lcd->data = *lcd->dataPtr;
	}
	if (lcd->name!=NULL)
	{
		_LCD_printstr(lcd->name, lcd);
	}
	lcd->showFunction(lcd->data, lcd);
}



void _LCD_Show_Clear_Area(LCD_Show_Structure * lcd)
{
	LCD_Fill_onecolor(
		LIMIT(lcd->left, 0, WIDTH),
		LIMIT(lcd->top, 0, HEIGHT),
		LIMIT(lcd->left + lcd->_width, 0, WIDTH),
		LIMIT(lcd->top + lcd->fontSize, 0, HEIGHT),
		0xffff);
}

void _LCD_Show_Draw_Border(LCD_Show_Structure * lcd)
{

	LCD_Draw_Rectangle(
		LIMIT(lcd->left - 1, 0, WIDTH),
		LIMIT(lcd->top - 1, 0, HEIGHT),
		LIMIT(lcd->left + lcd->_width, 0, WIDTH),
		LIMIT(lcd->top + lcd->fontSize, 0, HEIGHT)
	);
}